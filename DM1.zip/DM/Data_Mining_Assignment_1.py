import pandas as pd
import matplotlib.pyplot as plt

# Task 1: Read in the Default-of-Credit-Card-Clients.csv dataset using functions in Pandas package and print the data in the first two rows
DCCC = pd.read_csv("Default-of-Credit-Card-Clients.csv")
print(DCCC.head(2))

# Task 2: Print the names and data types of all the columns
print("The names and data types of all the column:")
print(DCCC.dtypes)
print()

# Task 3: Calculate and print the number of rows and columns that this dataset contains. We will not count the first row because it contains the column names.
Rows, Columns = DCCC.shape
print("N.of Rows -", Rows)
print("N.of Columns -", Columns)

# Task 4: Calculate and print the distinct values of the column “EDUCATION”.
Dist_Values = DCCC["EDUCATION"].unique()
print("Unique values of the EDUCATION column -", Dist_Values)

# Task 5: Calculate and print how many people have “default payment” = 1 and how many people have “default payment” = 0
print("Default payment - 1 =", DCCC["default payment next month"].sum())
print("Default payment - 0 =", len(DCCC) - DCCC["default payment next month"].sum())

# Task 6: Calculate and print count of married people with default payment = 1
Count_MP = DCCC[(DCCC["MARRIAGE"] == 1) & (DCCC["default payment next month"] == 1)].shape[0]
print("Count of married people with default payment = 1 is - ", Count_MP)

# Task 7: Calculate and print count of people with age > 30 and default payment = 1
Age_DP = DCCC[(DCCC["AGE"] > 30) & (DCCC["default payment next month"] == 1)].shape[0]
print("Count of people with age > 30 and default payment = 1 is:", Age_DP)

# Task 8: Calculate and print average LIMIT_BAL for male and female genders
AVG_Male = DCCC[DCCC["SEX"] == 1]["LIMIT_BAL"].mean()
AVG_Female = DCCC[DCCC["SEX"] == 2]["LIMIT_BAL"].mean()
# Can use the "round()" function to get the average values of decimal
print("Average LIMIT_BAL for male is:", AVG_Male)
print("Average LIMIT_BAL for female is:", AVG_Female)

# Task 9: Plot a histogram for the column “default payment” when age is less than or equal to 30. Plot a histogram for the column “default payment” when age is greater than 30
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
colors = ["black"]

axes[0].hist(DCCC[DCCC["AGE"] <= 30]["default payment next month"], edgecolor="red", color=colors)
axes[0].set_title("Default Payment Age <= 30")
axes[0].set_xlabel("Default Payment")
axes[0].set_ylabel("Frequency")

axes[1].hist(DCCC[DCCC["AGE"] > 30]["default payment next month"], edgecolor="red", color=colors)
axes[1].set_title("Default Payment Age > 30")
axes[1].set_xlabel("Default Payment")
axes[1].set_ylabel("Frequency")

plt.tight_layout()
plt.show()

# Task 10: Draw a scatter plot with the data of the “AGE” column and the “LIMIT_BAL” column. The x axis represents the “AGE” column and the y axis represents the “LIMIT_BAL” column
fig, ax = plt.subplots(figsize=(14, 12))
ax.scatter(DCCC["AGE"], DCCC["LIMIT_BAL"], alpha=0.25, c='black', edgecolors='grey')
ax.set_title("Scatter Plot of AGE vs LIMIT_BAL")
ax.set_xlabel("AGE")
ax.set_ylabel("LIMIT_BAL")
plt.show()